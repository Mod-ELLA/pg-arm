function install;
disp('Installing policy gradient libary...')

addpath Examples
addpath System
addpath Utility
addpath Library
savepath 

disp('Done! Try out LQR_1d_DF or TwoState_DF as examples!');