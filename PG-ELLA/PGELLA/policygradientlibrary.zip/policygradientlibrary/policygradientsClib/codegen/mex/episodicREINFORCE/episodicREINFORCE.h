/*
 * episodicREINFORCE.h
 *
 * Code generation for function 'episodicREINFORCE'
 *
 * C source code generated on: Tue Jul 29 16:12:56 2014
 *
 */

#ifndef __EPISODICREINFORCE_H__
#define __EPISODICREINFORCE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "episodicREINFORCE_types.h"

/* Function Declarations */
extern void episodicREINFORCE(const emlrtStack *sp, const b_struct_T *policy, const d_struct_T *data, const c_struct_T *param, emxArray_creal_T *dJdtheta);
#endif
/* End of code generation (episodicREINFORCE.h) */
