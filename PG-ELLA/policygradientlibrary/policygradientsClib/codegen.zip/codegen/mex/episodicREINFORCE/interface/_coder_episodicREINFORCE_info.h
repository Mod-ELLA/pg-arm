/*
 * _coder_episodicREINFORCE_info.h
 *
 * Code generation for function 'episodicREINFORCE'
 *
 * C source code generated on: Mon Jul 28 22:36:21 2014
 *
 */

#ifndef ___CODER_EPISODICREINFORCE_INFO_H__
#define ___CODER_EPISODICREINFORCE_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_episodicREINFORCE_info.h) */
